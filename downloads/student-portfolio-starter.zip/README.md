# Cybersecurity Portfolio Starter

1. Replace every instance of `YOUR NAME`.
2. Update the About, Projects, Skills, and Contact sections.
3. Replace the three sample project pages with approved course documentation.
4. Add sanitized screenshots and evidence. Caption every artifact.
5. Keep `index.html`, `styles.css`, and project pages in the repository root unless you intentionally change the links.
6. Upload the files to a public GitHub repository and enable GitHub Pages.
7. Test every link on desktop and mobile.
8. Review every file for passwords, tokens, grades, personal data, restricted course material, and private network details before publishing.

The starter contains no dead placeholder links. Each sample project opens a working page that can be customized.

Starter framework copyright 2026 MutaSpace. Student project content belongs to the student author.
