# Public Portfolio Privacy Check

- [ ] No passwords, tokens, keys, secrets, flags, or recovery codes.
- [ ] No grades, Canvas screenshots, private feedback, or student records.
- [ ] No real internal addresses, hostnames, organization diagrams, or unapproved findings.
- [ ] Screenshots are cropped and sanitized.
- [ ] Every evidence item has a useful caption.
- [ ] The project states that it was completed in an authorized learning environment.
- [ ] The instructor has been contacted before publishing anything questionable.
